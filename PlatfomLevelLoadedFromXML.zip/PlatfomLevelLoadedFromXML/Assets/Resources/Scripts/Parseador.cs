﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using UnityEngine.UI;
using System.Reflection;
using System.IO;

public class Parseador : MonoBehaviour {

    public Sprite[] tilesBackground, tilesTerrain;
    private XmlDocument xmlDoc;
    int cuentaCapas = 0, cuentaAltura = 0;
    string contenido, capaName;
    int width, height;
    float posX, posY;
    bool isTerrain;

    void Start () {

        tilesBackground = Resources.LoadAll<Sprite>("Sprites/BG");
        tilesTerrain = Resources.LoadAll<Sprite>("Sprites/terrain");
        LoadXMLFromAsset();
        ReadXML();
    }

    //Carga el fichero XML
    public void LoadXMLFromAsset()
    {
        xmlDoc = new XmlDocument();
        TextAsset textXml = (TextAsset)Resources.Load("Sprites/mapaChulo", typeof(TextAsset));
        xmlDoc.LoadXml(textXml.text);
    }

    //Genera el nivel de plataformas a partir de los datos del XML
    private void ReadXML()
    {
        foreach (XmlElement node in xmlDoc.SelectNodes("map/layer"))
        {
            posX = 0;
            posY = 0;

            width = int.Parse(node.GetAttribute("width"));
            height = int.Parse(node.GetAttribute("height"));
            capaName = node.GetAttribute("name");

            GameObject capa = new GameObject();
            capa.name = capaName;
            cuentaAltura = width; //Controla que la altura cambie cada vez que terminamos una fila

            //Cojo el texto de la capa y lo introduzco en un array
            contenido = node.SelectSingleNode("data").InnerText;
            string[] arrayContenido = new string[(width * height)];
            arrayContenido = contenido.Split(',');

            switch (capaName)
            {
                case "BackNubes": isTerrain = false; break;
                case "BackMontanias": isTerrain = false; break;
                case "BackCielo": isTerrain = false; break;
                default: isTerrain = true; break;
            }
            for (int i = 0; i < arrayContenido.Length; i++)
            {
                GameObject tile;

                if(isTerrain == true) //ARRAY DEL TERRENO
                {
                    if(int.Parse(arrayContenido[i]) != 0){
                        if(int.Parse(arrayContenido[i]) == 17) //Esto arregla el problema de que la imagen del agua superficial es un poco mas pequeña
                        {
                            tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY-0.3f), new Quaternion(0, 0, 0, 0)) as GameObject;
                            tile.GetComponent<SpriteRenderer>().sprite = tilesTerrain[int.Parse(arrayContenido[i]) - 1];
                            tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                            tile.name = capaName;
                            tile.transform.parent = capa.transform;
                        }
                        else
                        {
                            tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY), new Quaternion(0, 0, 0, 0)) as GameObject;
                            tile.GetComponent<SpriteRenderer>().sprite = tilesTerrain[int.Parse(arrayContenido[i]) - 1];
                            tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                            tile.name = capaName;
                            tile.transform.parent = capa.transform;
                            if (capaName == "BackTerreno") //Le añado transparencia porque es terreno de fondo
                            {
                                Color c = tile.GetComponent<SpriteRenderer>().color;
                                c.a = 0.8f;
                                tile.GetComponent<SpriteRenderer>().color = c;
                            }

                            switch (capaName)
                            {
                                case "BackTerreno": tile.AddComponent<ControlBackTerreno>(); break;
                                case "Terrain": tile.AddComponent<BoxCollider2D>(); break;
                                case "Plataformas":

                                    tile.AddComponent<BoxCollider2D>();
                                    if (tile.transform.position.x > 30) {
                                        tile.AddComponent<ControlPlataformas>();
                                        tile.tag = "PlataformaMovil";
                                    }
                                        break;
                                case "PlataformasCaen":
                                    tile.AddComponent<BoxCollider2D>();
                                    tile.AddComponent<ControlPlatCaen>();
                                    tile.tag = "PlatCaen";
                                    break;                                
                            }
                        }

                    }

                }
                else //ARRAY DEL BACKGROUND, hay que restar 19 a la posición
                {
                    if (int.Parse(arrayContenido[i]) != 0)
                    {
                        tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY), new Quaternion(0, 0, 0, 0)) as GameObject;          
                        tile.GetComponent<SpriteRenderer>().sprite = tilesBackground[int.Parse(arrayContenido[i]) - 19];
                        tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                        tile.name = capaName;
                        tile.transform.parent = capa.transform;

                        switch (capaName)
                        {
                            case "BackNubes": tile.AddComponent<ControlNubes>(); break;
                            case "BackMontanias": tile.AddComponent<ControlMontanias>(); break;
                        }
                    }
                }                

                if (i == cuentaAltura - 1)
                {
                    posX = 0;
                    posY = posY - 1.25f;
                    cuentaAltura += width;
                }
                else
                {
                    posX += 1.25f;
                }

            }

            cuentaCapas++;
        }
        
    }
}
