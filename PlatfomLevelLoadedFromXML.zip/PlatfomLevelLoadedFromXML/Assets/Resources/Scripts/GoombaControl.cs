﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoombaControl : MonoBehaviour {

    float posX;
    bool derecha=true;
    float speed = 0.05f;
    GameObject player;
	// Use this for initialization
	void Start () {
        posX = transform.position.x;
        InvokeRepeating("Disparo", 2, 3);
        player = GameObject.Find("player");
    }
	
	// Update is called once per frame
	void Update () {
		if(derecha == true)
        {
            transform.position = new Vector2(transform.position.x + speed, transform.position.y);
            if(transform.position.x - posX >= 1.5f)
            {
                derecha = false;
            }
        }
        else
        {
            transform.position = new Vector2(transform.position.x - speed, transform.position.y);
            if (transform.position.x - posX <= -1.5f)
            {
                derecha = true;
            }
        }
	}


    void Disparo()
    {
        Debug.Log(player.transform.position.x);
        if(player.transform.position.x > 82)
        {
            GameObject disparo = Instantiate(Resources.Load("Prefabs/bala"), new Vector2(transform.position.x, transform.position.y), new Quaternion(0, 0, 0, 0)) as GameObject;
        }
        
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name == "player")
        {
            other.gameObject.GetComponent<ControlPlayer>().GetDamage(20);
        }
    }


}
