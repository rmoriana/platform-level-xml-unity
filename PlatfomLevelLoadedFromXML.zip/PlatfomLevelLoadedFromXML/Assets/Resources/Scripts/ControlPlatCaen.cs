﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlPlatCaen : MonoBehaviour {

    public bool inMoving;
    bool subiendo;
    int posicion; //Establece el orden de las plataformas para poder diferenciarlas
    float posX,posY; //Posición inicial
                // Use this for initialization
    void Start () {
        posX = transform.position.x;
        posY = transform.position.y;
        //Este bucle diferencia las plataformas en grupos para que unas empiecen subiendo y otras bajando
        if(posX >= 85 && posX <= 89)
        {
            posicion = 1;
        } else if (posX >= 90 && posX <= 94)
        {
            posicion = 2;
        }
        else if (posX >= 97 && posX <= 101)
        {
            posicion = 3;
        }
        else
        {
            posicion = 4;
        }
        if(posicion == 1 || posicion == 3)
        {
            subiendo = false;
        }
        else
        {
            subiendo = true;
        }

    }
	
	// Update is called once per frame
	void Update () {
		if(inMoving == true)
        {
            if(subiendo == true)
            {
                transform.position = new Vector2(transform.position.x, transform.position.y + 0.025f);
                if(transform.position.y - posY >= 2)
                {
                    subiendo = false;
                }
            }
            else
            {
                transform.position = new Vector2(transform.position.x, transform.position.y - 0.025f);
                if (transform.position.y - posY <= -2)
                {
                    subiendo = true;
                }
            }
        }
	}

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name == "player")
        {
            GameObject[] plataformasCaen = GameObject.FindGameObjectsWithTag("PlatCaen");
            for (int i = 0; i < plataformasCaen.Length; i++)
            {
                plataformasCaen[i].GetComponent<ControlPlatCaen>().inMoving = true;
            }
             
        }
    }
}
