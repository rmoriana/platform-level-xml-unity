﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlCamera : MonoBehaviour {

    public GameObject player;
    float playerSpeed;
	// Use this for initialization
	void Start () {
        player = GameObject.Find("player");
        playerSpeed = player.GetComponent<ControlPlayer>().speed;
	}
	
	// Update is called once per frame
	void Update () {
		if(player.transform.position.x - transform.position.x > 3)
        {
            transform.position = new Vector3(transform.position.x + playerSpeed, transform.position.y, transform.position.z);
        }
        if (player.transform.position.x - transform.position.x < -3)
        {
            transform.position = new Vector3(transform.position.x - playerSpeed, transform.position.y, transform.position.z);
        }

        if(player.transform.position.y - transform.position.x < 0 && player.GetComponent<Animator>().GetBool("isJumping") == false)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y + ((player.transform.position.y - transform.position.y) / 75), transform.position.z);
        }

        if (!Input.GetKey(KeyCode.LeftArrow) && !Input.GetKey(KeyCode.RightArrow))
        {
            transform.position = new Vector3(transform.position.x + ((player.transform.position.x - transform.position.x) / 75), transform.position.y, transform.position.z);
        }
    }
}
