﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ControlPlayer : MonoBehaviour {

    public float speed = 0.1f;
    public Image LifePercent;
    private float healthPoints = 100;
    private bool isInmune;
	
	//El update controla el movimiento del jugador.
	void Update () {

        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.localScale = new Vector2(1.5f, transform.localScale.y);
            GetComponent<Animator>().SetBool("isWalking", true);
            transform.position = new Vector2(transform.position.x + speed, transform.position.y);

        } else if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.localScale = new Vector2(-1.5f, transform.localScale.y);
            GetComponent<Animator>().SetBool("isWalking", true);
            transform.position = new Vector2(transform.position.x - speed, transform.position.y);
        }
        else
        {
            GetComponent<Animator>().SetBool("isWalking", false);
        }

        if (Input.GetKeyDown(KeyCode.Space) && GetComponent<Animator>().GetBool("isJumping") == false)
        {
            GetComponent<Animator>().SetBool("isJumping", true);
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 35000));
        }
	}

    //Colisiones con el terreno
    void OnCollisionEnter2D(Collision2D other)
    {
        string name = other.gameObject.name;
        if(name == "Terrain" || name == "Plataformas" || name == "PlataformasCaen" && other.gameObject.transform.position.y < transform.position.y)
        {
            GetComponent<Animator>().SetBool("isJumping", false);
        }
    }

    //Movimiento de las plataformas
    private void OnCollisionStay2D(Collision2D other)
    {
        string tag = other.gameObject.tag;
        if(tag == "PlataformaMovil")
        {
            transform.position = new Vector2(transform.position.x + 0.02f, transform.position.y);
        }
    }

    //Colision con el agua y la zona de victoria
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "agua")
        {
            PlayerMuerto();
        }
        else if(other.gameObject.tag == "win")
        {
            Invoke("WinScene", 2);
        }
    }

    //Escena de game over
    public void PlayerMuerto()
    {
        SceneManager.LoadScene("GameOver");
    }

    //Gestion del daño
    public void GetDamage(int dmgPoints)
    {
        if (!isInmune)
        {
            isInmune = true;
            Invoke("StopInmunity", 2);
            Debug.Log(healthPoints);
            healthPoints -= dmgPoints;
            Debug.Log(healthPoints);
            LifePercent.fillAmount = healthPoints / 100;
            if (healthPoints <= 0)
            {
                PlayerMuerto();
            }
        }        
    }

    //El jugador deja de ser inmune
    private void StopInmunity()
    {
        isInmune = false;
    }

    //Carga la escena de victoria
    private void WinScene()
    {
        SceneManager.LoadScene("Victory");
    }
}
