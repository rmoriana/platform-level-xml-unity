﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlNubes : MonoBehaviour {

    float speed = 0.03f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position = new Vector2(transform.position.x - speed, transform.position.y);
        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position = new Vector2(transform.position.x + speed, transform.position.y);
        }
        else
        {
            transform.position = new Vector2(transform.position.x - 0.004f, transform.position.y);
        }

        if(transform.position.x <= 0)
        {
            transform.position = new Vector2(135, transform.position.y);
        }
    }
}
