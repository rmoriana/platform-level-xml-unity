<?xml version="1.0" encoding="UTF-8"?>
<tileset name="BG" tilewidth="128" tileheight="128" tilecount="35" columns="7">
 <image source="../../../../freetileset/png/BG/BG.png" width="1000" height="750"/>
</tileset>
